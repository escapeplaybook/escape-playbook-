import { useState } from "react";
import Head from "next/head";

export default function Account() {
  const [email, setEmail] = useState("");
  const [orders, setOrders] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [searched, setSearched] = useState(false);

  async function lookup(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSearched(true);
    try {
      const res = await fetch("/api/account/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Lookup failed");
      setOrders(data.orders);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="status-page">
      <Head>
        <title>My Purchases</title>
      </Head>
      <h1>My Purchases</h1>
      <p>Enter the email you purchased with to get fresh download links.</p>

      <form className="account-form" onSubmit={lookup}>
        <input
          type="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? "Searching…" : "Find My Purchases"}
        </button>
      </form>

      {error && <div className="error-box">{error}</div>}

      {searched && !loading && !error && orders && orders.length === 0 && (
        <p>No paid orders found for that email.</p>
      )}

      {orders &&
        orders.map((order) => (
          <div className="order-block" key={order.orderId}>
            <h3>{order.productName}</h3>
            <div className="meta">
              Purchased {new Date(order.paidAt).toLocaleDateString()} · Order {order.orderId}
            </div>
            <div className="file-list">
              {order.files.map((file) => (
                <div className="file-row" key={file.key}>
                  <span className="name">{file.displayName}</span>
                  {file.url ? (
                    <a className="download-btn" href={file.url} target="_blank" rel="noreferrer">
                      Download
                    </a>
                  ) : (
                    <span className="download-btn download-btn--disabled">Unavailable</span>
                  )}
                </div>
              ))}
            </div>
            {order.community && (
              <div className="community-box">
                <strong>{order.community.label}</strong>
                <p>{order.community.instructions}</p>
                <a href={order.community.url} target="_blank" rel="noreferrer">
                  {order.community.url}
                </a>
              </div>
            )}
          </div>
        ))}
    </div>
  );
}
