import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Link from "next/link";

export default function Success() {
  const router = useRouter();
  const { orderId } = router.query;
  const [access, setAccess] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;
    fetch(`/api/access/${orderId}`)
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not load your purchase");
        setAccess(data);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [orderId]);

  return (
    <div className="status-page">
      <Head>
        <title>Purchase Successful</title>
      </Head>

      {loading && <p>Loading your access…</p>}

      {!loading && error && (
        <>
          <h1>We couldn't load your purchase</h1>
          <p>{error}</p>
          <p>
            If you were just charged, this can take a few seconds — refresh this page. If it
            keeps happening, contact support with your order ID: <code>{orderId}</code>.
          </p>
        </>
      )}

      {!loading && access && (
        <>
          <h1>Welcome to {access.productName}.</h1>
          <p>Your purchase was successful. Your products are ready.</p>

          <div className="file-list">
            {access.files.map((file) => (
              <div className="file-row" key={file.key}>
                <span className="name">{file.displayName}</span>
                {file.url ? (
                  <a className="download-btn" href={file.url} target="_blank" rel="noreferrer">
                    Download
                  </a>
                ) : (
                  <span className="download-btn download-btn--disabled">Unavailable</span>
                )}
              </div>
            ))}
          </div>

          {access.community && (
            <div className="community-box">
              <strong>{access.community.label}</strong>
              <p>{access.community.instructions}</p>
              <a href={access.community.url} target="_blank" rel="noreferrer">
                {access.community.url}
              </a>
            </div>
          )}

          <p style={{ marginTop: 32, fontSize: 13 }}>
            Bookmark this page, or visit <Link href="/account">My Purchases</Link> anytime and
            enter your email to get fresh download links (these links expire after an hour for
            security).
          </p>
        </>
      )}
    </div>
  );
}
