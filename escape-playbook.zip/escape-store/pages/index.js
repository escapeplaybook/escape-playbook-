import Head from "next/head";
import Link from "next/link";
import { getAllProducts } from "../config/products";
import ProductCard from "../components/ProductCard";

export default function Home({ products }) {
  return (
    <>
      <Head>
        <title>Escape Playbook — Making Money With Digital Products</title>
        <meta
          name="description"
          content="Real, step-by-step guides for building and selling digital products."
        />
      </Head>

      <header className="site-header">
        <div className="container site-header__inner">
          <div className="logo">
            {/* Replace /public/images/logo.png with your real logo */}
            <img src="/images/logo.png" alt="Escape Playbook logo" onError={(e) => (e.target.style.display = "none")} />
            Escape Playbook
          </div>
          <nav className="header-links">
            <Link href="/account">My Purchases</Link>
          </nav>
        </div>
      </header>

      <section className="hero">
        <div className="container">
          <h1>Making Money With Digital Products</h1>
          <p>
            Real, step-by-step guides — no fluff, no fake promises. Pick the guide that fits
            where you are.
          </p>
        </div>
      </section>

      <section className="container product-grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </section>

      <footer>
        <div className="container">
          &copy; {new Date().getFullYear()} Escape Playbook. All rights reserved.
        </div>
      </footer>
    </>
  );
}

export async function getStaticProps() {
  return { props: { products: getAllProducts() } };
}
