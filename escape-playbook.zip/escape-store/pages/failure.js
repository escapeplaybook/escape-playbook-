import Head from "next/head";
import Link from "next/link";

export default function Failure() {
  return (
    <div className="status-page">
      <Head>
        <title>Payment Not Completed</title>
      </Head>
      <h1>Payment wasn't completed.</h1>
      <p>No charge was made and no product access was granted.</p>
      <Link className="try-again-btn" href="/">
        TRY AGAIN
      </Link>
    </div>
  );
}
