import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Script from "next/script";
import { getProduct, getAllProducts } from "../../config/products";

export default function Checkout({ product }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [paypalReady, setPaypalReady] = useState(false);

  if (!product) {
    return (
      <div className="status-page">
        <h1>Product not found</h1>
      </div>
    );
  }

  function validateEmail() {
    if (!email || !email.includes("@")) {
      setError("Please enter a valid email address — this is where your access will be tied to.");
      return false;
    }
    setError("");
    return true;
  }

  async function payWithRazorpay() {
    if (!validateEmail()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/checkout/razorpay/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to start checkout");

      const rzp = new window.Razorpay({
        key: data.keyId,
        amount: data.amount,
        currency: data.currency,
        name: "Escape Playbook",
        description: data.productName,
        order_id: data.razorpayOrderId,
        prefill: { email },
        handler: async function (response) {
          try {
            const verifyRes = await fetch("/api/checkout/razorpay/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                localOrderId: data.localOrderId,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                email,
              }),
            });
            const verifyData = await verifyRes.json();
            if (!verifyRes.ok) throw new Error(verifyData.error || "Verification failed");
            router.push(`/success?orderId=${verifyData.orderId}`);
          } catch (e) {
            router.push("/failure");
          }
        },
        modal: {
          ondismiss: function () {
            setLoading(false);
          },
        },
        theme: { color: "#1F3A5F" },
      });

      rzp.on("payment.failed", function () {
        router.push("/failure");
      });

      rzp.open();
    } catch (e) {
      setError(e.message);
      setLoading(false);
    }
  }

  return (
    <div className="checkout-page">
      <Head>
        <title>Checkout — {product.name}</title>
      </Head>

      {/* Razorpay's checkout widget script */}
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />

      {/* PayPal SDK — client ID is public by design (not a secret) */}
      <Script
        src={`https://www.paypal.com/sdk/js?client-id=${process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID || ""}&currency=USD`}
        strategy="lazyOnload"
        onLoad={() => setPaypalReady(true)}
      />

      <div className="checkout-summary">
        <h2>{product.name}</h2>
        <p>{product.tagline}</p>
        <div className="price">${product.price.usd}</div>
        <ul>
          {product.includes.map((item) => (
            <li key={item}>✓ {item}</li>
          ))}
        </ul>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="field">
        <label htmlFor="email">Email (your access will be sent here)</label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
        />
      </div>

      <div className="payment-methods">
        <button className="pay-btn pay-btn--razorpay" onClick={payWithRazorpay} disabled={loading}>
          {loading ? "Processing…" : "Pay with Razorpay (Cards / UPI / Netbanking)"}
        </button>

        {paypalReady && email.includes("@") ? (
          <PaypalButton product={product} email={email} />
        ) : (
          <button className="pay-btn pay-btn--paypal" disabled>
            Enter your email to enable PayPal
          </button>
        )}
      </div>
    </div>
  );
}

function PaypalButton({ product, email }) {
  const containerRef = useRef(null);
  const localOrderIdRef = useRef(null);
  const renderedRef = useRef(false);

  useEffect(() => {
    if (renderedRef.current) return; // only render the PayPal button once
    if (typeof window === "undefined" || !window.paypal || !containerRef.current) return;

    renderedRef.current = true;

    window.paypal
      .Buttons({
        createOrder: async () => {
          const res = await fetch("/api/checkout/paypal/create-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ productId: product.id, email }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || "Failed to start checkout");
          localOrderIdRef.current = data.localOrderId;
          return data.paypalOrderId;
        },
        onApprove: async (approveData) => {
          const res = await fetch("/api/checkout/paypal/capture", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              localOrderId: localOrderIdRef.current,
              paypalOrderId: approveData.orderID,
              email,
            }),
          });
          const data = await res.json();
          if (!res.ok) {
            window.location.href = "/failure";
            return;
          }
          window.location.href = `/success?orderId=${data.orderId}`;
        },
        onError: () => {
          window.location.href = "/failure";
        },
        onCancel: () => {
          window.location.href = "/";
        },
      })
      .render(containerRef.current);
  }, [product.id, email]);

  return <div ref={containerRef} />;
}

export async function getStaticPaths() {
  const products = getAllProducts();
  return {
    paths: products.map((p) => ({ params: { productId: p.id } })),
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const product = getProduct(params.productId);
  if (!product) return { notFound: true };
  return { props: { product } };
}
