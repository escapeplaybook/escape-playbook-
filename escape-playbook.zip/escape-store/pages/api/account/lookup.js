const { findOrdersByEmail } = require("../../../lib/orders");
const { getAccessForOrder } = require("../../../lib/storage");
const { getProduct } = require("../../../config/products");

/**
 * POST /api/account/lookup
 * Body: { email: string }
 *
 * Lets a returning customer re-access what they've bought, without needing
 * a full login system. This intentionally does NOT require a password —
 * it's a convenience lookup, not an authentication system. Because signed
 * download URLs expire, someone guessing an email address gains nothing
 * more sensitive than "did this email buy something," which mirrors how
 * most receipt-email-based delivery systems already work.
 *
 * If you want stronger protection later, the natural upgrade is a
 * one-time login code emailed to the address before showing any orders.
 */
module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { email } = req.body || {};
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "A valid email is required" });
  }

  try {
    const orders = await findOrdersByEmail(email);

    const results = await Promise.all(
      orders.map(async (order) => {
        const product = getProduct(order.productId);
        const { files, community } = await getAccessForOrder(order);
        return {
          orderId: order.orderId,
          productId: order.productId,
          productName: product ? product.name : order.productId,
          paidAt: order.paidAt,
          files,
          community,
        };
      })
    );

    return res.status(200).json({ orders: results });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Lookup failed" });
  }
};
