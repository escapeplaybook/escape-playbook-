const { verifyRazorpaySignature } = require("../../../../lib/razorpay");
const {
  getOrder,
  findOrderByProviderOrderId,
  markOrderPaid,
  markOrderFailed,
} = require("../../../../lib/orders");

/**
 * Called by the browser immediately after Razorpay's checkout widget
 * completes. This does NOT trust the browser's word that payment succeeded —
 * it re-verifies the cryptographic signature Razorpay provides, and only
 * marks the order paid if that verification passes.
 */
module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const {
    localOrderId,
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature,
    email,
  } = req.body || {};

  if (!localOrderId || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ error: "Missing required payment fields" });
  }

  try {
    const order = await getOrder(localOrderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    if (order.providerOrderId !== razorpay_order_id) {
      return res.status(400).json({ error: "Order mismatch" });
    }

    const isValid = verifyRazorpaySignature({
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    });

    if (!isValid) {
      await markOrderFailed(localOrderId);
      return res.status(400).json({ error: "Payment verification failed" });
    }

    const paidOrder = await markOrderPaid(localOrderId, { email });
    return res.status(200).json({ success: true, orderId: paidOrder.orderId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Verification failed" });
  }
};
