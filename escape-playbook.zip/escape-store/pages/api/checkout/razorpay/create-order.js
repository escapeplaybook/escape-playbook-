const { getProduct, getProductPriceINRPaise } = require("../../../../config/products");
const { createRazorpayOrder } = require("../../../../lib/razorpay");
const { createPendingOrder, attachProviderOrderId } = require("../../../../lib/orders");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { productId, email } = req.body || {};
  const product = getProduct(productId);
  if (!product) {
    return res.status(400).json({ error: "Unknown product" });
  }

  try {
    const amountPaise = getProductPriceINRPaise(productId);

    // Create our own pending order FIRST. Verification later checks against
    // this record, not against anything the browser claims happened.
    const localOrder = await createPendingOrder({
      productId,
      email,
      provider: "razorpay",
      amount: amountPaise,
      currency: "INR",
    });

    const rzpOrder = await createRazorpayOrder({
      amountPaise,
      currency: "INR",
      receipt: localOrder.orderId,
    });

    await attachProviderOrderId(localOrder.orderId, rzpOrder.id);

    return res.status(200).json({
      localOrderId: localOrder.orderId,
      razorpayOrderId: rzpOrder.id,
      amount: rzpOrder.amount,
      currency: rzpOrder.currency,
      keyId: process.env.RAZORPAY_KEY_ID,
      productName: product.name,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to create Razorpay order" });
  }
};
