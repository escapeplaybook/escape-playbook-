const { getProduct } = require("../../../../config/products");
const { createPaypalOrder } = require("../../../../lib/paypal");
const { createPendingOrder, attachProviderOrderId } = require("../../../../lib/orders");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { productId, email } = req.body || {};
  const product = getProduct(productId);
  if (!product) {
    return res.status(400).json({ error: "Unknown product" });
  }

  try {
    const amountCents = Math.round(product.price.usd * 100);

    const localOrder = await createPendingOrder({
      productId,
      email,
      provider: "paypal",
      amount: amountCents,
      currency: "USD",
    });

    const paypalOrder = await createPaypalOrder({
      amountUSD: product.price.usd,
      referenceId: localOrder.orderId,
    });

    await attachProviderOrderId(localOrder.orderId, paypalOrder.id);

    return res.status(200).json({
      localOrderId: localOrder.orderId,
      paypalOrderId: paypalOrder.id,
      productName: product.name,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to create PayPal order" });
  }
};
