const { capturePaypalOrder } = require("../../../../lib/paypal");
const { getOrder, markOrderPaid, markOrderFailed } = require("../../../../lib/orders");

/**
 * Called by the browser once the customer approves payment in the PayPal
 * popup/redirect. This performs the actual CAPTURE call to PayPal's API
 * server-side — the browser cannot fake a successful capture, because the
 * capture call itself only succeeds if PayPal's servers confirm the funds
 * were actually collected.
 */
module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { localOrderId, paypalOrderId, email } = req.body || {};
  if (!localOrderId || !paypalOrderId) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    const order = await getOrder(localOrderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    if (order.providerOrderId !== paypalOrderId) {
      return res.status(400).json({ error: "Order mismatch" });
    }

    const capture = await capturePaypalOrder(paypalOrderId);
    const status = capture?.status;

    if (status !== "COMPLETED") {
      await markOrderFailed(localOrderId);
      return res.status(400).json({ error: `PayPal payment not completed (status: ${status})` });
    }

    const capturedEmail = capture?.payer?.email_address || email || null;
    const paidOrder = await markOrderPaid(localOrderId, { email: capturedEmail });
    return res.status(200).json({ success: true, orderId: paidOrder.orderId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Capture failed" });
  }
};
