const { getOrder } = require("../../../lib/orders");
const { getAccessForOrder } = require("../../../lib/storage");
const { getProduct } = require("../../../config/products");

/**
 * GET /api/access/[orderId]
 *
 * Returns the product info + signed, short-lived download links for exactly
 * the files that order's product includes. This is the single enforcement
 * point for "only give the customer what they paid for" — it never trusts
 * anything from the browser except the orderId, and it looks up everything
 * else (status, product, files) from the database and config.
 *
 * A pending/failed/cancelled order returns no files, regardless of what the
 * frontend might display.
 */
module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { orderId } = req.query;
  if (!orderId) {
    return res.status(400).json({ error: "Missing orderId" });
  }

  try {
    const order = await getOrder(orderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    if (order.status !== "paid") {
      return res.status(403).json({
        error: "This order has not been paid for.",
        status: order.status,
      });
    }

    const product = getProduct(order.productId);
    const { files, community } = await getAccessForOrder(order);

    return res.status(200).json({
      orderId: order.orderId,
      productId: order.productId,
      productName: product ? product.name : order.productId,
      paidAt: order.paidAt,
      files,
      community,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to load access details" });
  }
};
