/**
 * ============================================================================
 * CENTRAL PRODUCT CONFIGURATION
 * ============================================================================
 * This is the ONLY place you should need to edit to:
 *   - change a price
 *   - change a description
 *   - add/remove a file from a product
 *   - change what's included in the bundle
 *   - temporarily disable a product (set `available: false`)
 *
 * Nothing else in the codebase hard-codes product names, prices, or files.
 * Every page and API route reads from this file.
 *
 * FILE PATHS: the `key` values inside `files` must match keys defined in
 * config/files.js — that's where the actual file locations on disk live.
 * Keeping the "what's included" list (here) separate from "where is it on
 * disk" (files.js) means you can move/rename files without touching pricing
 * or product descriptions, and vice versa.
 * ============================================================================
 */

const PRODUCTS = {
  "escape-playbook": {
    id: "escape-playbook",
    name: "Escape Playbook",
    tagline: "Learn the fundamentals of creating and selling digital products.",
    description:
      "The main digital product about making money with digital products — a complete, step-by-step guide from idea to first sale.",
    price: {
      usd: 20,
      inr: 1699, // adjust to your desired INR price; Razorpay charges in paise (handled automatically)
    },
    image: "/images/escape-playbook-cover.jpg",
    badge: null,
    features: [
      "Real, actionable step-by-step process — not theory",
      "Covers niche validation, pricing, and platform selection",
      "Written to be read once and acted on immediately",
    ],
    includes: ["Making Money With Digital Products PDF"],
    files: ["escape-playbook-pdf"],
    includesTools: false,
    includesTemplates: false,
    includesCommunity: false,
    available: true,
  },

  "implementation-plan": {
    id: "implementation-plan",
    name: "Implementation Plan",
    tagline: "Turn the knowledge into a practical execution plan.",
    description:
      "A practical implementation system designed to help you turn the information from the Escape Playbook into action — day by day.",
    price: {
      usd: 30,
      inr: 2499,
    },
    image: "/images/implementation-plan-cover.jpg",
    badge: null,
    features: [
      "Day-by-day execution roadmap",
      "Time estimates and deliverables for every task",
      "Copy-and-use templates included inside the PDF",
    ],
    includes: ["Implementation Plan PDF"],
    files: ["implementation-plan-pdf"],
    includesTools: false,
    includesTemplates: false,
    includesCommunity: false,
    available: true,
  },

  "complete-escape-bundle": {
    id: "complete-escape-bundle",
    name: "Complete Escape Bundle",
    tagline: "Everything you need in one package.",
    description:
      "The full system: both guides, the tools, the templates, and community access — bundled at the best value.",
    price: {
      usd: 50,
      inr: 4199,
    },
    image: "/images/complete-bundle-cover.jpg",
    badge: "BEST VALUE",
    featured: true,
    features: [
      "Everything in Escape Playbook",
      "Everything in Implementation Plan",
      "Bonus tools and free templates",
      "Access to the private community",
    ],
    includes: [
      "Escape Playbook",
      "Implementation Plan",
      "Tools",
      "Community access",
      "Free templates",
    ],
    files: [
      "escape-playbook-pdf",
      "implementation-plan-pdf",
      "tools-pdf",
      "templates-zip",
    ],
    includesTools: true,
    includesTemplates: true,
    includesCommunity: true,
    available: true,
  },
};

// Order in which products appear on the offer/pricing page.
const PRODUCT_ORDER = [
  "escape-playbook",
  "implementation-plan",
  "complete-escape-bundle",
];

function getAllProducts() {
  return PRODUCT_ORDER.map((id) => PRODUCTS[id]).filter((p) => p && p.available);
}

function getProduct(productId) {
  return PRODUCTS[productId] || null;
}

function getProductPriceUSD(productId) {
  const p = getProduct(productId);
  return p ? p.price.usd : null;
}

function getProductPriceINRPaise(productId) {
  const p = getProduct(productId);
  return p ? Math.round(p.price.inr * 100) : null; // Razorpay expects paise
}

module.exports = {
  PRODUCTS,
  PRODUCT_ORDER,
  getAllProducts,
  getProduct,
  getProductPriceUSD,
  getProductPriceINRPaise,
};
