/**
 * ============================================================================
 * FILE REGISTRY
 * ============================================================================
 * Maps a file "key" (referenced in config/products.js) to where it lives
 * inside your private Supabase Storage bucket, plus its download display
 * name.
 *
 * All real files live in a PRIVATE Supabase Storage bucket named
 * "digital-products" (private = no public URL works, ever — the only way to
 * get a file out is a short-lived signed URL generated server-side after we
 * confirm the customer paid for it; see lib/storage.js).
 *
 * TO REPLACE A PLACEHOLDER WITH YOUR REAL FILE:
 *   1. Open Supabase Dashboard → Storage → digital-products bucket.
 *   2. Upload your real file to the exact `storagePath` shown below
 *      (create the folder if it doesn't exist yet), OR change the
 *      `storagePath` value here to match whatever path you uploaded to.
 *   3. That's it — no code changes needed anywhere else.
 * ============================================================================
 */

const BUCKET = "digital-products";

const FILES = {
  "escape-playbook-pdf": {
    key: "escape-playbook-pdf",
    displayName: "Making Money With Digital Products.pdf",
    storagePath: "escape-playbook/making-money-with-digital-products.pdf",
    contentType: "application/pdf",
  },
  "implementation-plan-pdf": {
    key: "implementation-plan-pdf",
    displayName: "Implementation Plan.pdf",
    storagePath: "implementation-plan/implementation-plan.pdf",
    contentType: "application/pdf",
  },
  "tools-pdf": {
    key: "tools-pdf",
    displayName: "Tools.pdf",
    storagePath: "tools/tools.pdf",
    contentType: "application/pdf",
  },
  "templates-zip": {
    key: "templates-zip",
    displayName: "Free Templates.zip",
    storagePath: "templates/free-templates.zip",
    contentType: "application/zip",
  },
};

// Community access isn't a downloadable file — it's a link + instructions
// shown on the success/account pages for any product with
// includesCommunity: true. Edit this whenever your community URL changes.
const COMMUNITY_ACCESS = {
  label: "Private Community Access",
  url: "https://REPLACE-WITH-YOUR-COMMUNITY-URL.example.com",
  instructions:
    "Click the link above and use the email you purchased with to request access.",
};

function getFile(key) {
  return FILES[key] || null;
}

module.exports = { FILES, COMMUNITY_ACCESS, getFile, BUCKET };
