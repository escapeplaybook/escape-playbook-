/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Do NOT set output: 'export' — this app uses API routes (server
  // functions) for payments and secure downloads, which static export
  // cannot support. The @netlify/plugin-nextjs plugin (configured in
  // netlify.toml) handles deploying these as Netlify Functions automatically.
};

module.exports = nextConfig;
