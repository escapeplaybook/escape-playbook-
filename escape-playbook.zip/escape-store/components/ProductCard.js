import Link from "next/link";

export default function ProductCard({ product }) {
  return (
    <div className={`product-card ${product.featured ? "product-card--featured" : ""}`}>
      {product.badge && <div className="product-card__badge">{product.badge}</div>}

      <div className="product-card__image">
        {/* Replace the file at /public/images/... to change this cover */}
        <img src={product.image} alt={`${product.name} cover`} />
      </div>

      <h3 className="product-card__name">{product.name}</h3>
      <p className="product-card__tagline">{product.tagline}</p>

      <div className="product-card__price">
        <span className="product-card__price-amount">${product.price.usd}</span>
        <span className="product-card__price-note">one-time</span>
      </div>

      <p className="product-card__description">{product.description}</p>

      <div className="product-card__includes">
        <p className="product-card__includes-label">Includes:</p>
        <ul>
          {product.includes.map((item) => (
            <li key={item}>
              <span className="check">✓</span> {item}
            </li>
          ))}
        </ul>
      </div>

      <Link href={`/checkout/${product.id}`} className="product-card__cta">
        GET {product.name.toUpperCase()}
      </Link>
    </div>
  );
}
