# Escape Playbook

A digital product storefront: customers browse three products, pay with Razorpay (India) or PayPal (international), and get secure, time-limited download access to exactly what they paid for — no more, no less.

---

## 1. Features

- Three products (Escape Playbook, Implementation Plan, Complete Escape Bundle) driven entirely by one config file — no product data hard-coded in components.
- Razorpay checkout (cards/UPI/netbanking) and PayPal checkout, both verified **server-side** before any access is granted.
- Files are stored in a **private** Supabase Storage bucket — never publicly reachable by URL. Access is a short-lived signed link generated only after payment is confirmed.
- Product-level access rules: a $20 buyer can never reach the $50 bundle's files, enforced in one place (`lib/storage.js`), not scattered across pages.
- A lightweight "My Purchases" page so returning customers can re-fetch fresh download links with just their email.
- Ready for GitHub → Netlify with automatic deploys on every push.

---

## 2. Tech Stack

| Layer | Choice | Why |
|---|---|---|
| Framework | Next.js 14 (Pages Router) | Official Netlify support for API routes as serverless functions, via `@netlify/plugin-nextjs` |
| Hosting | Netlify | Requested; works out of the box with the plugin above |
| Database | Supabase (Postgres) | Free tier, no server to manage, works statelessly with serverless functions (unlike a local file-based DB, which does not persist on Netlify) |
| File storage | Supabase Storage (private bucket) | Same project as the database — one dashboard, one set of credentials. Built-in signed URLs remove the need for a custom file-serving system |
| Payments | Razorpay + PayPal (raw REST calls) | No extra SDK dependencies; smaller, easier-to-audit codebase |

---

## 3. Project Structure

```
config/
  products.js       ← THE single source of truth for names, prices, descriptions, features, and which files each product includes
  files.js           ← maps a file key to its path inside Supabase Storage
lib/
  supabaseAdmin.js    ← server-only Supabase client (service role key)
  orders.js            ← all order database reads/writes
  storage.js            ← turns a paid order into signed download links
  razorpay.js            ← Razorpay order creation + signature verification
  paypal.js                ← PayPal order creation + capture
pages/
  index.js                  ← offer/pricing page (reads config/products.js)
  checkout/[productId].js    ← checkout page, both payment methods
  success.js                  ← post-payment access page
  failure.js                    ← payment failed/cancelled page
  account.js                     ← "My Purchases" email lookup
  api/
    checkout/razorpay/*           ← create-order, verify
    checkout/paypal/*               ← create-order, capture
    access/[orderId].js               ← returns signed links for a paid order
    account/lookup.js                   ← returns all paid orders for an email
supabase/
  schema.sql                            ← run once to create the orders table
```

To add a fourth product later: add one entry to `config/products.js` and one entry to `config/files.js`. Nothing else needs to change.

---

## 4. Local Setup

### 4.1 Install dependencies

```bash
npm install
```

### 4.2 Create a Supabase project

1. Go to [supabase.com](https://supabase.com) → New Project (free tier is enough to start).
2. Once created, go to **Project → SQL Editor → New query**, paste the contents of `supabase/schema.sql`, and click **Run**. This creates the `orders` table.
3. Go to **Storage** → **New bucket** → name it exactly `digital-products` → set it to **Private** (not public).
4. Inside that bucket, create these folders and upload files matching `config/files.js`:
   ```
   escape-playbook/making-money-with-digital-products.pdf
   implementation-plan/implementation-plan.pdf
   tools/tools.pdf
   templates/free-templates.zip
   ```
5. Go to **Project → Settings → API**. Copy the **Project URL** and the **`service_role` secret key** (not the `anon` key).

### 4.3 Set up Razorpay

1. Sign up at [razorpay.com](https://razorpay.com) and complete KYC (required before you can accept real payments; test mode works immediately).
2. Go to **Settings → API Keys** → generate a Key ID and Key Secret.

### 4.4 Set up PayPal

1. Sign up at [developer.paypal.com](https://developer.paypal.com).
2. Go to **Apps & Credentials** → create an app → copy the **Client ID** and **Secret**.
3. Use **Sandbox** credentials while testing; switch to **Live** credentials when you're ready for real payments (and change `PAYPAL_API_BASE` accordingly).

### 4.5 Environment variables

```bash
cp .env.example .env.local
```

Fill in every value in `.env.local` using the credentials from steps 4.2–4.4. See the comments in `.env.example` for what each one is and where to find it.

### 4.6 Run locally

```bash
npm run dev
```

Visit `http://localhost:3000`.

---

## 5. Replacing Placeholder Assets

| Asset | Where it goes |
|---|---|
| PDFs / templates zip | Upload into the Supabase Storage `digital-products` bucket, at the paths listed in `config/files.js` |
| Product cover images | Replace the files in `public/images/` (same filenames, or update the `image` field in `config/products.js`) |
| Logo | Replace `public/images/logo.png` |
| Favicon | Replace `public/favicon.ico` |
| Community URL | Edit `COMMUNITY_ACCESS.url` in `config/files.js` |
| Prices / descriptions / features | Edit `config/products.js` — nothing else needs to change |

The placeholder cover images currently in `public/images/` are clearly labeled "REPLACE THIS PLACEHOLDER COVER IMAGE" so nothing looks like a finished, real asset until you swap it.

---

## 6. GitHub Deployment

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/escape-playbook.git
git push -u origin main
```

`.gitignore` already excludes `.env`, `.env.local`, `node_modules`, and build output — no secrets will be committed as long as you only ever put real credentials in `.env.local` (never in a tracked file).

---

## 7. Netlify Deployment

1. Go to [app.netlify.com](https://app.netlify.com) → **Add new site → Import an existing project**.
2. Choose **GitHub** and select your `escape-playbook` repository.
3. Netlify will detect `netlify.toml` automatically. Confirm these build settings (they're already set in `netlify.toml`, but double-check):
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
   - **Node version:** `18.18.0` (set via `netlify.toml`; no manual entry needed)
4. Before deploying, add environment variables: **Site configuration → Environment variables → Add a variable**, and add every variable from `.env.example` with your real values:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`
   - `PAYPAL_CLIENT_ID`
   - `PAYPAL_CLIENT_SECRET`
   - `PAYPAL_API_BASE` (start with the sandbox URL, switch to live later)
   - `NEXT_PUBLIC_PAYPAL_CLIENT_ID` (same value as `PAYPAL_CLIENT_ID`)
   - `DOWNLOAD_TOKEN_SECRET` (any long random string)
5. Click **Deploy site**.

### Automatic deployments

Once connected, every `git push` to `main` triggers a new Netlify build automatically — you don't need to do anything in Netlify after the first setup. Push a change locally, and the live site updates within a minute or two.

### Custom domain

**Site configuration → Domain management → Add a domain** — follow Netlify's prompts to point your domain's DNS at Netlify.

---

## 8. Webhooks (optional, but recommended for production)

The app already verifies payments synchronously (right after checkout), so webhooks are not strictly required to function. They're a useful backup for the rare case where a customer closes their browser after paying but before the verify/capture call finishes.

- **Razorpay:** Dashboard → **Settings → Webhooks** → Add a webhook pointing to `https://YOUR-SITE.netlify.app/api/webhooks/razorpay` (this endpoint is not included by default in this build — add one following the pattern in `pages/api/checkout/razorpay/verify.js` if you want this extra safety net).
- **PayPal:** Developer Dashboard → your app → **Webhooks** → Add `https://YOUR-SITE.netlify.app/api/webhooks/paypal`.
- Never point a webhook at `localhost` — providers can't reach your local machine. To test webhooks locally, use a tunneling tool like `ngrok` and update the webhook URL temporarily.

---

## 9. Production Testing Checklist

- [ ] Visit the live Netlify URL — offer page loads with all three products.
- [ ] Complete a real (or Razorpay/PayPal sandbox) purchase for each product.
- [ ] Confirm the success page shows only the files that specific product includes.
- [ ] Confirm a $20 purchase never shows bundle-only files.
- [ ] Cancel a checkout partway through — confirm you land back on the offer page with no access granted.
- [ ] Force a failed payment (e.g. sandbox decline card) — confirm the failure page appears and no access is granted.
- [ ] Visit `/account`, enter the email used in a real purchase, confirm past orders and fresh download links appear.
- [ ] Open the site on a phone — checkout and download buttons should be easy to tap.

---

## 10. Troubleshooting

| Problem | Likely cause | Fix |
|---|---|---|
| "Supabase is not configured" error | Missing/incorrect `SUPABASE_URL` or `SUPABASE_SERVICE_ROLE_KEY` | Double-check both in Netlify's environment variables (or `.env.local` locally) |
| Razorpay button does nothing | Ad blocker, or `checkout.razorpay.com` script blocked | Test in a different browser/incognito window |
| PayPal button never appears | `NEXT_PUBLIC_PAYPAL_CLIENT_ID` missing or email field empty | The PayPal button only renders once a valid email is entered — check the env var is set and redeployed |
| "File not available yet" on the success page | The file hasn't been uploaded to Supabase Storage at the exact path in `config/files.js` | Check the bucket path matches exactly, including folder names and file extension |
| Netlify build fails | Node version mismatch or missing dependency | Confirm `NODE_VERSION` in `netlify.toml`; try `npm install` locally first to catch errors before pushing |
| Local dev works but Netlify deploy doesn't grant access after payment | Environment variables not set in Netlify (they don't carry over from `.env.local`) | Re-check every variable is added under Site configuration → Environment variables, then redeploy |
| Customer says they paid but got no access | Check Supabase **Table Editor → orders** — if the row shows `status: pending`, verification never completed (browser closed too early) | Set up the optional webhooks in section 8 as a backup, or manually look up the payment in Razorpay/PayPal and update the order's status in Supabase |

---

## 11. Security Notes

- Payment credentials (Razorpay secret, PayPal secret, Supabase service role key) exist only as environment variables on the server — never in frontend code, never committed to Git.
- Every payment is verified server-side (`lib/razorpay.js` signature check; `lib/paypal.js` capture call) before any order is marked paid.
- Digital files live in a private Supabase Storage bucket with no public URL. Every download link is a signed URL generated after checking the order's paid status, and expires after 1 hour.
- The `orders` table has Row Level Security enabled; the app only ever reads/writes it using the service role key from server-side code, so a browser can never query it directly.
