-- ============================================================================
-- SUPABASE SCHEMA — run this once in the Supabase SQL editor
-- (Project → SQL Editor → New query → paste this → Run)
-- ============================================================================

create table if not exists orders (
  order_id uuid primary key default gen_random_uuid(),
  product_id text not null,
  email text,
  provider text not null check (provider in ('razorpay', 'paypal')),
  provider_order_id text,
  amount integer not null,          -- smallest currency unit (paise for INR, cents for USD)
  currency text not null,
  status text not null default 'pending' check (status in ('pending', 'paid', 'failed', 'cancelled')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

-- Speeds up "find my past purchases by email" on the Account page.
create index if not exists orders_email_idx on orders (email);

-- Speeds up matching a provider's webhook/callback to our internal order.
create index if not exists orders_provider_order_id_idx on orders (provider_order_id);

-- Row Level Security: locked down by default. All reads/writes in this app
-- go through the server using the SERVICE ROLE key (which bypasses RLS by
-- design), so the public anon key — if you ever add one — cannot read or
-- write orders directly from the browser.
alter table orders enable row level security;
